from distutils.core import setup

setup(
		name		= 'fgh-nester',
		version		= '1.2.0',
		py_modules	= ['nester'],
		author		= 'fghinzelli',
		author_email	= 'fghinzelli@gmail.com',
		url			= 'http://fghz16.com',
		description		= 'A simple printer of nested lists',
	)