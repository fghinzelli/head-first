from distutils.core import setup

setup(
		name		= 'nester',
		version		= '1.0.0',
		py_modules	= ['nester'],
		author		= 'fgpython',
		author_email	= 'fgpython@python.com',
		url			= 'http://abobrinha.com',
		description		= 'A simple printer of nested lists',
	)